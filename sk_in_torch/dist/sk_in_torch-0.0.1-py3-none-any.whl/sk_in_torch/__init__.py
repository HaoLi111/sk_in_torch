from file import method 

# 'method' is a function that is present in a file called 'file.py'