# sk_in_torch

Some torch models in sklearn format.

Goal:

Installation of pytorch is everywhere Why not use torch to compute some of the traditional models as well? Also, it is possible to make torch conform to sklearn's grammar, making it almost plug and play. Here are some of the results & I show you that sklearn and packages in sklearn style (like linear-tree) can work with these functions seamlessly.

Quickstart:


an early version of call is at https://www.kaggle.com/code/hli111111/sklearn-in-pytorch-with-gpu
note that you do not need to rewrite the classes if you import this.